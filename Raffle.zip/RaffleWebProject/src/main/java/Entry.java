
public class Entry {

}
